# handlers/moderation.py
from telegram import Update
from telegram.ext import ContextTypes, MessageHandler, filters
from telegram.constants import ChatMemberStatus
import datetime
import re
import os

from utils.db_json import get_group_settings, update_group_settings

# --- Fungsi Utility Internal ---
def is_owner(user_id):
    """Mengecek apakah user_id adalah owner bot."""
    return str(user_id) == os.getenv("OWNER_ID")

async def is_admin_or_owner(chat_id, user_id, context: ContextTypes.DEFAULT_TYPE):
    """Mengecek apakah user adalah admin grup atau owner bot."""
    if is_owner(user_id):
        return True
    
    try:
        chat_member = await context.bot.get_chat_member(chat_id, user_id)
        if chat_member.status in [ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR]:
            return True
    except Exception as e:
        print(f"Error checking admin status: {e}")
    return False

async def get_target_user_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mendapatkan User ID target dari reply atau argumen."""
    target_user_id = None
    if update.message.reply_to_message:
        target_user_id = update.message.reply_to_message.from_user.id
    elif context.args and context.args[0].startswith('@'):
        # Mendapatkan user ID dari username butuh logic lebih.
        # Bisa pakai get_chat_member jika username adalah admin, atau minta user join dulu.
        # Untuk kasus ini, kita akan minta User ID langsung jika bukan reply.
        await update.message.reply_text("Untuk target username, mohon balas pesannya atau berikan User ID langsung (misal: `/kick 123456789`).")
        return None
    elif context.args and context.args[0].isdigit():
        target_user_id = int(context.args[0])
    
    if target_user_id == context.bot.id:
        await update.message.reply_text("Saya tidak bisa melakukan tindakan ini pada diri saya sendiri.")
        return None
    if target_user_id == int(os.getenv("OWNER_ID")):
        await update.message.reply_text("Saya tidak bisa melakukan tindakan ini pada owner bot.")
        return None
    
    return target_user_id

# --- Handler Bot ---

async def kick_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command untuk kick member."""
    if not update.effective_chat.type in ['group', 'supergroup']:
        await update.message.reply_text("Perintah ini hanya bisa digunakan di grup.")
        return

    if not await is_admin_or_owner(update.effective_chat.id, update.effective_user.id, context):
        await update.message.reply_text("Kamu harus menjadi admin grup atau owner bot untuk menggunakan perintah ini.")
        return

    target_user_id = await get_target_user_id(update, context)
    if not target_user_id:
        return

    try:
        await context.bot.kick_chat_member(chat_id=update.effective_chat.id, user_id=target_user_id)
        await update.message.reply_text(f"User `{target_user_id}` berhasil dikeluarkan dari grup.")
    except Exception as e:
        await update.message.reply_text(f"Gagal mengeluarkan user. Error: `{e}`")


async def ban_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command untuk ban member."""
    if not update.effective_chat.type in ['group', 'supergroup']:
        await update.message.reply_text("Perintah ini hanya bisa digunakan di grup.")
        return

    if not await is_admin_or_owner(update.effective_chat.id, update.effective_user.id, context):
        await update.message.reply_text("Kamu harus menjadi admin grup atau owner bot untuk menggunakan perintah ini.")
        return

    target_user_id = await get_target_user_id(update, context)
    if not target_user_id:
        return

    try:
        await context.bot.ban_chat_member(chat_id=update.effective_chat.id, user_id=target_user_id)
        await update.message.reply_text(f"User `{target_user_id}` berhasil dibanned dari grup.")
    except Exception as e:
        await update.message.reply_text(f"Gagal membanned user. Error: `{e}`")


async def mute_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command untuk mute member."""
    if not update.effective_chat.type in ['group', 'supergroup']:
        await update.message.reply_text("Perintah ini hanya bisa digunakan di grup.")
        return

    if not await is_admin_or_owner(update.effective_chat.id, update.effective_user.id, context):
        await update.message.reply_text("Kamu harus menjadi admin grup atau owner bot untuk menggunakan perintah ini.")
        return

    target_user_id = await get_target_user_id(update, context)
    if not target_user_id:
        return

    duration = None
    if len(context.args) > 1:
        time_str = context.args[1].lower()
        if time_str.endswith('m'):
            duration = int(time_str[:-1]) * 60 # menit ke detik
        elif time_str.endswith('h'):
            duration = int(time_str[:-1]) * 3600 # jam ke detik
        elif time_str.endswith('d'):
            duration = int(time_str[:-1]) * 86400 # hari ke detik
        else:
            await update.message.reply_text("Format waktu tidak valid. Gunakan `30m`, `1h`, atau `7d`.")
            return

    permissions = {
        'can_send_messages': False,
        'can_send_media_messages': False,
        'can_send_polls': False,
        'can_send_other_messages': False,
        'can_add_web_page_previews': False,
        'can_change_info': False,
        'can_invite_users': False,
        'can_pin_messages': False,
    }
    
    try:
        until_date = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=duration) if duration else None
        await context.bot.restrict_chat_member(
            chat_id=update.effective_chat.id,
            user_id=target_user_id,
            permissions=permissions,
            until_date=until_date
        )
        if duration:
            await update.message.reply_text(f"User `{target_user_id}` berhasil dibisukan selama `{context.args[1]}`.")
        else:
            await update.message.reply_text(f"User `{target_user_id}` berhasil dibisukan (permanen).")
    except Exception as e:
        await update.message.reply_text(f"Gagal membisukan user. Error: `{e}`")


# --- Anti-Link Logic ---
LINK_REGEX = r"(https?://\S+)" # Regex sederhana untuk mendeteksi link

async def anti_link_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mendeteksi dan menghapus pesan yang mengandung link."""
    if not update.message or not update.message.text:
        return # Abaikan jika bukan pesan teks

    chat_id = update.effective_chat.id
    user_id = update.effective_user.id
    message_id = update.message.message_id
    
    # Cek apakah user adalah admin atau owner bot (whitelist otomatis)
    if await is_admin_or_owner(chat_id, user_id, context):
        return

    # Cek apakah anti-link aktif di grup ini (opsional, bisa selalu aktif)
    group_settings = get_group_settings(chat_id)
    if not group_settings.get("anti_link_enabled", True): # Default True jika tidak diset
        return

    text = update.message.text
    if re.search(LINK_REGEX, text):
        try:
            await context.bot.delete_message(chat_id=chat_id, message_id=message_id)
            # Opsional: Beri peringatan ke user atau mute user
            # await update.message.reply_text(f"Pesan dari {update.effective_user.mention_html()} mengandung link dan telah dihapus.", parse_mode='HTML')
        except Exception as e:
            print(f"Failed to delete message with link in chat {chat_id}: {e}")

async def toggle_anti_link_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command untuk mengaktifkan/menonaktifkan anti-link."""
    if not update.effective_chat.type in ['group', 'supergroup']:
        await update.message.reply_text("Perintah ini hanya bisa digunakan di grup.")
        return

    if not await is_admin_or_owner(update.effective_chat.id, update.effective_user.id, context):
        await update.message.reply_text("Kamu harus menjadi admin grup atau owner bot untuk menggunakan perintah ini.")
        return

    group_settings = get_group_settings(update.effective_chat.id)
    current_status = group_settings.get("anti_link_enabled", True)
    
    new_status = not current_status
    update_group_settings(update.effective_chat.id, {"anti_link_enabled": new_status})
    
    status_text = "diaktifkan" if new_status else "dinonaktifkan"
    await update.message.reply_text(f"Mode Anti-Link di grup ini berhasil **{status_text}**.")

