# handlers/downloader.py
import yt_dlp
import os
import asyncio # Untuk menjalankan yt-dlp secara non-blocking
from telegram import Update
from telegram.ext import ContextTypes
import re

from handlers.premium import get_user_current_limit, increment_request_count
from utils.db_json import update_user_data # Untuk reset requests_today jika diperlukan

DOWNLOAD_DIR = "downloads"
if not os.path.exists(DOWNLOAD_DIR):
    os.makedirs(DOWNLOAD_DIR)

async def _download_and_send(update: Update, context: ContextTypes.DEFAULT_TYPE, url: str, is_photo_pinterest: bool = False):
    """Fungsi internal untuk mendownload dan mengirim file."""
    user_id = update.effective_user.id
    
    # Cek batas request
    remaining_requests, user_role = get_user_current_limit(user_id)
    if remaining_requests <= 0:
        await update.message.reply_text(
            f"Maaf, kamu sudah mencapai batas request harian untuk pengguna {user_role.title()}. "
            "Silakan coba lagi besok, atau /upgrade ke Premium untuk 100x request per hari!"
        )
        return

    message = await update.message.reply_text("Sedang memproses... Mohon tunggu sebentar.")
    
    try:
        ydl_opts = {
            'format': 'best',
            'outtmpl': os.path.join(DOWNLOAD_DIR, '%(id)s.%(ext)s'),
            'noplaylist': True,
            'max_downloads': 1,
            'quiet': True,
            'no_warnings': True,
            'retries': 3,
            'fragment_retries': 3,
            'ignoreerrors': True, # Lanjutkan jika ada error kecil
        }

        if is_photo_pinterest:
            # Untuk Pinterest, kita mungkin hanya ingin gambar terbaik
            ydl_opts['format'] = 'bestvideo[ext=webp]+bestaudio/best' # Coba format terbaik untuk gambar
            ydl_opts['extract_flat'] = 'in_playlist' # Jangan download playlist, hanya item
            ydl_opts['match_filter'] = yt_dlp.utils.match_filter_func('is_live = false & protocol != "m3u8_native"') # Hindari live streams
            ydl_opts['max_filesize'] = 50 * 1024 * 1024 # Batasi ukuran file misal 50MB
            ydl_opts['postprocessors'] = [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }, {
                'key': 'FFmpegVideoRemuxer',
                'preferedformat': 'mp4',
            }]
            # Untuk Pinterest, yt-dlp bisa jadi tidak optimal untuk gambar.
            # Mungkin perlu web scraping atau custom logic jika hanya butuh gambar.
            # Untuk demo ini, kita asumsikan yt-dlp bisa handle image dengan baik.
            # Jika user minta "foto" dari pinterest, seringkali itu memang video pendek.
            # Atau bisa juga gunakan https://pin.it/ link langsung untuk gambar.
        else:
            # Umumnya untuk video
            ydl_opts['max_filesize'] = 200 * 1024 * 1024 # Batasi ukuran video misal 200MB

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info_dict = await asyncio.to_thread(ydl.extract_info, url, download=True)
            filename = ydl.prepare_filename(info_dict)

            if os.path.exists(filename):
                if info_dict.get('__postprocessors')[0].get('key') == 'FFmpegExtractAudio': # ini kalau download audio
                    await context.bot.send_audio(chat_id=user_id, audio=open(filename, 'rb'))
                elif 'video' in info_dict.get('__postprocessors', [{}])[0].get('key', '').lower():
                     await context.bot.send_video(chat_id=user_id, video=open(filename, 'rb'))
                else: # Default kirim sebagai dokumen jika tipe tidak jelas
                    await context.bot.send_document(chat_id=user_id, document=open(filename, 'rb'))

                os.remove(filename) # Hapus file setelah dikirim
                await message.edit_text(f"Berhasil! Sisa request: {remaining_requests - 1}/{user_role.title()}")
                increment_request_count(user_id) # Tambah hitungan request setelah berhasil
            else:
                await message.edit_text("Gagal mengunduh file. Link mungkin tidak valid atau tidak didukung.")
    except Exception as e:
        print(f"Error downloading {url}: {e}")
        await message.edit_text(f"Terjadi kesalahan saat memproses link. Pesan error: `{e}`")
    finally:
        # Pastikan membersihkan file yang mungkin tersisa jika ada error
        for f in os.listdir(DOWNLOAD_DIR):
            if f.startswith(info_dict.get('id', 'temp_')) and os.path.isfile(os.path.join(DOWNLOAD_DIR, f)):
                os.remove(os.path.join(DOWNLOAD_DIR, f))


async def fb_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk command .fb."""
    if not context.args:
        await update.message.reply_text("Sertakan link Facebook. Contoh: `.fb https://facebook.com/ajaososjsjo`")
        return
    url = context.args[0]
    await _download_and_send(update, context, url)

async def yt_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk command .yt."""
    if not context.args:
        await update.message.reply_text("Sertakan link YouTube. Contoh: `.yt https://www.youtube.com/watch?v=xxxxxxxx`")
        return
    url = context.args[0]
    await _download_and_send(update, context, url)

async def ig_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk command .ig."""
    if not context.args:
        await update.message.reply_text("Sertakan link Instagram. Contoh: `.ig https://instagram.com/p/contohpost`")
        return
    url = context.args[0]
    await _download_and_send(update, context, url)

async def pin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk command .pin (Pinterest)."""
    # Untuk Pinterest, ini bisa link langsung atau keyword pencarian.
    # yt-dlp lebih ke link langsung. Untuk keyword, perlu scraping Pinterest.
    # Untuk demo, kita asumsikan user akan memberikan link Pinterest.
    if not context.args:
        await update.message.reply_text("Sertakan link Pinterest (foto/video). Contoh: `.pin https://pin.it/xxxxx`")
        return
    url = context.args[0]
    # Pinterest bisa jadi video atau gambar. yt-dlp akan mencoba mengunduh yang terbaik.
    await _download_and_send(update, context, url, is_photo_pinterest=True)

