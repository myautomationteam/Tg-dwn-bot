# handlers/premium.py
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
import datetime
import os
import uuid # Untuk ID transaksi unik

from utils.db_json import load_db, save_db, get_user_data, update_user_data, add_transaction_record, get_transaction_record, update_transaction_record
from utils.constants import PREMIUM_PRICES, BASIC_DAILY_LIMIT, PREMIUM_DAILY_LIMIT

# --- Fungsi Utility Internal ---
def is_owner(user_id):
    """Mengecek apakah user_id adalah owner bot."""
    return str(user_id) == os.getenv("OWNER_ID")

def get_or_create_user(user_id):
    """Mendapatkan data user atau membuat yang baru jika belum ada."""
    user_data = get_user_data(user_id)
    if not user_data:
        user_data = {
            "role": "basic",
            "requests_today": 0,
            "last_request_timestamp": None,
            "premium_end_date": None
        }
        update_user_data(user_id, user_data)
    return user_data

def get_user_current_limit(user_id):
    """Mengembalikan batas request harian user."""
    user_data = get_or_create_user(user_id)
    
    # Reset limit jika hari sudah berganti
    now = datetime.datetime.now(datetime.timezone.utc) # UTC untuk konsistensi
    last_req_str = user_data.get("last_request_timestamp")
    
    if last_req_str:
        last_req_dt = datetime.datetime.fromisoformat(last_req_str.replace('Z', '+00:00')) # Parse ISO format
        # Cek apakah sudah hari berikutnya atau sudah melewati waktu reset (misal 00:00)
        # Sederhana: cek apakah tanggal berbeda. Lebih akurat: cek waktu reset harian tertentu.
        if (now.date() > last_req_dt.date()) or \
           (now.date() == last_req_dt.date() and now.hour < last_req_dt.hour): # Jika reset di tengah malam
            user_data["requests_today"] = 0
            update_user_data(user_id, {"requests_today": 0})

    # Cek premium expiry
    if user_data["role"] == "premium" and user_data.get("premium_end_date"):
        premium_end_dt = datetime.datetime.fromisoformat(user_data["premium_end_date"].replace('Z', '+00:00'))
        if now > premium_end_dt:
            user_data["role"] = "basic"
            user_data["premium_end_date"] = None
            update_user_data(user_id, {"role": "basic", "premium_end_date": None})
            
    if user_data["role"] == "premium":
        return PREMIUM_DAILY_LIMIT - user_data["requests_today"], "premium"
    else:
        return BASIC_DAILY_LIMIT - user_data["requests_today"], "basic"

def increment_request_count(user_id):
    """Menambah hitungan request user."""
    user_data = get_or_create_user(user_id)
    user_data["requests_today"] += 1
    user_data["last_request_timestamp"] = datetime.datetime.now(datetime.timezone.utc).isoformat() + 'Z'
    update_user_data(user_id, user_data)


# --- Handler Bot ---

async def upgrade_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menampilkan pilihan paket premium."""
    user_id = update.effective_user.id
    
    keyboard = []
    for key, value in PREMIUM_PRICES.items():
        label = key.replace("_", " ").title()
        keyboard.append([InlineKeyboardButton(f"{label}: Rp{value['price']:,}", callback_data=f"select_premium_{key}")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "🎉 Selamat! Pilih paket Premium yang kamu inginkan:\n"
        "Dengan Premium, kamu dapat **100x request per hari**, fitur prioritas, dan tanpa antrean!",
        reply_markup=reply_markup,
        parse_mode='Markdown'
    )

async def select_premium_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menangani pilihan paket premium dan mengirim QRIS."""
    query = update.callback_query
    await query.answer() # Menghilangkan loading di tombol

    user_id = query.from_user.id
    package_key = query.data.replace("select_premium_", "")
    
    package_info = PREMIUM_PRICES.get(package_key)
    if not package_info:
        await query.edit_message_text("Terjadi kesalahan, paket tidak ditemukan. Coba lagi.")
        return

    price = package_info["price"]
    qris_path = os.getenv(package_info["qris_path_key"])
    
    if not qris_path or not os.path.exists(qris_path):
        await query.edit_message_text("Maaf, gambar QRIS untuk paket ini tidak tersedia. Hubungi admin.")
        return
    
    # Simpan status transaksi sementara di database (atau dalam context.user_data jika sederhana)
    # Gunakan UUID sebagai ID transaksi unik
    transaction_id = str(uuid.uuid4())
    add_transaction_record(transaction_id, {
        "user_id": user_id,
        "username": query.from_user.username or query.from_user.full_name,
        "package_key": package_key,
        "price": price,
        "status": "pending_screenshot",
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat() + 'Z',
        "transaction_id": transaction_id # Simpan ID ini juga di record
    })
    
    await context.bot.send_photo(
        chat_id=user_id,
        photo=open(qris_path, 'rb'),
        caption=f"Silakan scan QRIS ini dan transfer **Rp{price:,}** untuk paket {package_key.replace('_', ' ').title()}.\n\n"
                "Setelah pembayaran, **balas pesan ini dengan screenshot bukti transfermu.**\n"
                f"ID Transaksi Anda: `{transaction_id}`\n"
                "*(Pastikan screenshot terlihat jelas)*",
        parse_mode='Markdown'
    )
    await query.edit_message_text(
        f"Instruksi pembayaran untuk paket {package_key.replace('_', ' ').title()} sudah dikirim ke DM kamu. Silakan cek."
    )


async def handle_payment_screenshot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menangani screenshot bukti pembayaran dan mengirim notifikasi ke admin."""
    user_id = update.effective_user.id
    
    # Cek apakah ini balasan dari pesan QRIS yang bot kirim
    # Ini memerlukan bot untuk menyimpan ID pesan QRIS yang dikirim atau ID transaksi yang berkaitan
    # Untuk contoh ini, kita asumsikan user akan langsung mengirim screenshot setelah QRIS
    
    # Ambil transaksi yang statusnya 'pending_screenshot' dari user ini
    # Ini mungkin perlu iterasi atau query lebih kompleks di db_json
    db = load_db()
    active_transaction = None
    for tid, transaction_data in db["transactions"].items():
        if transaction_data.get("user_id") == user_id and transaction_data.get("status") == "pending_screenshot":
            active_transaction = transaction_data
            break
    
    if not active_transaction:
        await update.message.reply_text("Maaf, saya tidak menemukan permintaan upgrade yang aktif untuk Anda. Silakan mulai ulang dengan /upgrade.")
        return

    # Pastikan ada foto di pesan
    if not update.message.photo:
        await update.message.reply_text("Mohon kirimkan screenshot bukti transfermu sebagai foto.")
        return
    
    photo_file = await update.message.photo[-1].get_file() # Ambil foto kualitas tertinggi
    
    # Update status transaksi
    active_transaction["status"] = "waiting_admin_verification"
    active_transaction["screenshot_file_id"] = photo_file.file_id
    active_transaction["received_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat() + 'Z'
    update_transaction_record(active_transaction["transaction_id"], active_transaction)

    # Kirim notifikasi ke owner
    owner_id = os.getenv("OWNER_ID")
    if owner_id:
        # Buat tombol inline untuk admin
        keyboard = [
            [InlineKeyboardButton(
                "✅ Proses Premium", 
                callback_data=f"admin_process_premium_{active_transaction['transaction_id']}"
            )],
            [InlineKeyboardButton(
                "❌ Tolak Pembayaran", 
                callback_data=f"admin_reject_payment_{active_transaction['transaction_id']}"
            )]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        await context.bot.send_photo(
            chat_id=owner_id,
            photo=photo_file.file_id, # Kirim file ID foto langsung
            caption=f"🔔 **NOTIFIKASI PEMBAYARAN BARU!**\n\n"
                    f"**Dari:** {active_transaction['username']} (ID: `{active_transaction['user_id']}`)\n"
                    f"**Dugaan Paket:** {active_transaction['package_key'].replace('_', ' ').title()} (Rp{active_transaction['price']:,})\n"
                    f"**ID Transaksi:** `{active_transaction['transaction_id']}`\n"
                    f"**Status:** Menunggu Verifikasi Admin.\n\n"
                    "Mohon cek dan proses.",
            parse_mode='Markdown',
            reply_markup=reply_markup
        )
        await update.message.reply_text("Screenshot bukti transfermu sudah terkirim. Admin akan segera memverifikasinya. Mohon tunggu ya!")
    else:
        await update.message.reply_text("Screenshot bukti transfermu sudah terkirim. Admin akan memverifikasi secara manual. Mohon tunggu ya!")


async def admin_process_premium_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk admin memproses premium via tombol inline."""
    query = update.callback_query
    await query.answer()

    if not is_owner(query.from_user.id):
        await query.edit_message_text("Kamu bukan owner bot.")
        return

    transaction_id = query.data.replace("admin_process_premium_", "")
    transaction = get_transaction_record(transaction_id)

    if not transaction:
        await query.edit_message_text("Transaksi tidak ditemukan atau sudah diproses.")
        return

    if transaction["status"] == "processed":
        await query.edit_message_text("Transaksi ini sudah diproses sebelumnya.")
        return

    user_id_to_upgrade = transaction["user_id"]
    package_key = transaction["package_key"]
    package_info = PREMIUM_PRICES.get(package_key)

    if not package_info:
        await query.edit_message_text(f"Error: Paket '{package_key}' tidak valid.")
        return

    # Hitung tanggal berakhir premium
    duration_days = package_info["days"]
    premium_end_date = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=duration_days)
    
    # Update status user di database
    update_user_data(user_id_to_upgrade, {
        "role": "premium",
        "premium_end_date": premium_end_date.isoformat() + 'Z'
    })

    # Update status transaksi
    update_transaction_record(transaction_id, {"status": "processed", "processed_by": query.from_user.id})

    # Notifikasi ke admin dan user
    await query.edit_message_text(
        f"✅ Premium untuk User ID `{user_id_to_upgrade}` (Paket: {package_key.replace('_', ' ').title()}) berhasil diaktifkan hingga `{premium_end_date.strftime('%d %b %Y %H:%M UTC')}`.",
        parse_mode='Markdown'
    )
    try:
        await context.bot.send_message(
            chat_id=user_id_to_upgrade,
            text=f"🎉 Selamat, {transaction['username']}! Pembayaranmu sudah terverifikasi. Akunmu kini **Premium** hingga `{premium_end_date.strftime('%d %b %Y %H:%M UTC')}`! Nikmati 100x request harianmu.",
            parse_mode='Markdown'
        )
    except Exception as e:
        print(f"Failed to notify user {user_id_to_upgrade}: {e}") # Log jika gagal kirim pesan

async def admin_reject_payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handler untuk admin menolak pembayaran via tombol inline."""
    query = update.callback_query
    await query.answer()

    if not is_owner(query.from_user.id):
        await query.edit_message_text("Kamu bukan owner bot.")
        return

    transaction_id = query.data.replace("admin_reject_payment_", "")
    transaction = get_transaction_record(transaction_id)

    if not transaction:
        await query.edit_message_text("Transaksi tidak ditemukan atau sudah diproses.")
        return
    
    if transaction["status"] == "processed":
        await query.edit_message_text("Transaksi ini sudah diproses.")
        return

    update_transaction_record(transaction_id, {"status": "rejected", "rejected_by": query.from_user.id})

    await query.edit_message_text(
        f"❌ Pembayaran untuk User ID `{transaction['user_id']}` (ID Transaksi: `{transaction_id}`) telah ditolak.",
        parse_mode='Markdown'
    )
    try:
        await context.bot.send_message(
            chat_id=transaction["user_id"],
            text=f"Maaf, {transaction['username']}. Pembayaranmu dengan ID Transaksi `{transaction_id}` tidak dapat diverifikasi. Mohon hubungi admin jika ada kendala.",
            parse_mode='Markdown'
        )
    except Exception as e:
        print(f"Failed to notify user {transaction['user_id']} about rejection: {e}")

async def addprem_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Command owner untuk menambahkan premium secara manual: .addprem <user_id> <tahun> <bulan> <hari>."""
    if not is_owner(update.effective_user.id):
        await update.message.reply_text("Maaf, command ini hanya untuk owner bot.")
        return

    args = context.args
    if len(args) != 4:
        await update.message.reply_text("Format salah. Gunakan: `.addprem <user_id> <tahun> <bulan> <hari>`")
        return
    
    try:
        user_id = int(args[0])
        year = int(args[1])
        month = int(args[2])
        day = int(args[3])
        
        premium_end_date = datetime.datetime(year, month, day, 23, 59, 59, tzinfo=datetime.timezone.utc) # Akhir hari
        
        user_data = get_or_create_user(user_id)
        update_user_data(user_id, {
            "role": "premium",
            "premium_end_date": premium_end_date.isoformat() + 'Z'
        })
        
        await update.message.reply_text(
            f"✅ User `{user_id}` berhasil diaktifkan Premium hingga `{premium_end_date.strftime('%d %b %Y %H:%M UTC')}`."
        )
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text=f"🎉 Selamat! Admin telah mengaktifkan akun **Premium** Anda hingga `{premium_end_date.strftime('%d %b %Y %H:%M UTC')}`! Nikmati 100x request harian Anda."
            )
        except Exception as e:
            print(f"Failed to notify user {user_id}: {e}")

    except ValueError:
        await update.message.reply_text("Pastikan User ID, tahun, bulan, dan hari adalah angka valid.")
    except Exception as e:
        await update.message.reply_text(f"Terjadi error: {e}")

