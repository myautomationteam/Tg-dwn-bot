# main.py
import os
import logging
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters

# Load environment variables from .env file
load_dotenv()

# Setup logging (opsional, tapi sangat direkomendasikan)
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Ambil token bot dan owner ID dari .env
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
OWNER_ID = os.getenv("OWNER_ID") # Disimpan sebagai string, tapi digunakan sebagai int

# Pastikan token dan owner ID ada
if not TOKEN:
    raise ValueError("TELEGRAM_BOT_TOKEN not found in .env file.")
if not OWNER_ID:
    raise ValueError("OWNER_ID not found in .env file.")

# Import handlers
from handlers.downloader import fb_command, yt_command, ig_command, pin_command
from handlers.moderation import kick_command, ban_command, mute_command, anti_link_message_handler, toggle_anti_link_command
from handlers.premium import upgrade_command, select_premium_callback, handle_payment_screenshot, admin_process_premium_callback, admin_reject_payment_callback, addprem_command, get_user_current_limit, increment_request_count # Import juga fungsi cek limit

# --- Basic Commands ---
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menangani command /start."""
    user = update.effective_user
    await update.message.reply_html(
        f"Halo {user.mention_html()}! Aku adalah Bot Downloader multi-platform dan penjaga grup.\n"
        "Aku bisa unduh video dari FB, YouTube, IG, dan foto dari Pinterest.\n"
        "Ketik /info untuk melihat semua perintahku."
    )

async def info_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menampilkan informasi bot dan command."""
    user_id = update.effective_user.id
    remaining_requests, user_role = get_user_current_limit(user_id) # Pastikan fungsi ini tersedia

    info_text = (
        "Aku bisa:\n"
        "• Unduh Video/Foto: `.fb <link>`, `.yt <link>`, `.ig <link>`, `.pin <link>`\n"
        "• Moderasi Grup (perlu admin grup):\n"
        "  - `.kick <reply/user_id>`\n"
        "  - `.ban <reply/user_id>`\n"
        "  - `.mute <reply/user_id> [waktu]` (contoh: `30m`, `1h`, `7d`)\n"
        "  - `.antilink` (toggle anti-link di grup)\n"
        "\n"
        f"**Batas Harianmu ({user_role.title()}):** Sisa: {remaining_requests}\n"
        f"Total ({user_role.title()}): {PREMIUM_DAILY_LIMIT if user_role == 'premium' else BASIC_DAILY_LIMIT}\n"
        "Inovasi Premium! Ketik `/upgrade` untuk 100x request per hari!\n"
    )
    # Tambahkan info premium expiry jika user_role adalah premium
    if user_role == 'premium':
        user_data = get_user_data(user_id) # Perlu import get_user_data dari db_json
        premium_end = user_data.get("premium_end_date")
        if premium_end:
            premium_end_dt = datetime.datetime.fromisoformat(premium_end.replace('Z', '+00:00'))
            info_text += f"Premium Exp: `{premium_end_dt.strftime('%d %b %Y %H:%M UTC')}`\n"


    await update.message.reply_text(info_text, parse_mode='Markdown')

# --- Main function to run the bot ---
def main():
    """Menjalankan bot."""
    application = Application.builder().token(TOKEN).build()

    # Register Handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("info", info_command))

    # Downloader Handlers
    application.add_handler(CommandHandler("fb", fb_command))
    application.add_handler(CommandHandler("FB", fb_command)) # Alias
    application.add_handler(CommandHandler("facebook", fb_command)) # Alias
    application.add_handler(CommandHandler("yt", yt_command))
    application.add_handler(CommandHandler("ig", ig_command))
    application.add_handler(CommandHandler("pin", pin_command))

    # Premium Handlers
    application.add_handler(CommandHandler("upgrade", upgrade_command))
    application.add_handler(CallbackQueryHandler(select_premium_callback, pattern=r"^select_premium_"))
    application.add_handler(MessageHandler(filters.PHOTO & filters.PRIVATE, handle_payment_screenshot)) # Tangani screenshot di private chat
    application.add_handler(CallbackQueryHandler(admin_process_premium_callback, pattern=r"^admin_process_premium_"))
    application.add_handler(CallbackQueryHandler(admin_reject_payment_callback, pattern=r"^admin_reject_payment_"))
    
    # Owner Command Handler
    application.add_handler(CommandHandler("addprem", addprem_command)) # Contoh owner command

    # Moderation Handlers
    application.add_handler(CommandHandler("kick", kick_command))
    application.add_handler(CommandHandler("ban", ban_command))
    application.add_handler(CommandHandler("mute", mute_command))
    application.add_handler(CommandHandler("antilink", toggle_anti_link_command)) # Command untuk toggle anti-link
    application.add_handler(MessageHandler(filters.TEXT & filters.ChatType.GROUPS, anti_link_message_handler)) # Anti-link listener di grup

    # Run the bot
    logger.info("Bot is starting...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)
    logger.info("Bot stopped.")

if __name__ == "__main__":
    from handlers.premium import get_or_create_user # Diperlukan untuk info_command
    from utils.db_json import get_user_data # Diperlukan untuk info_command
    from utils.constants import BASIC_DAILY_LIMIT, PREMIUM_DAILY_LIMIT # Diperlukan untuk info_command
    import datetime # Diperlukan untuk info_command
    main()

