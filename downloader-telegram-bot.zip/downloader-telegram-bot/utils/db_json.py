# utils/db_json.py
import json
import os
from filelock import FileLock

# Ambil path database dari .env
DATABASE_FILE = os.getenv("DATABASE_FILE", "data.json")
LOCK_FILE = f"{DATABASE_FILE}.lock"

def load_db():
    """Membaca seluruh data dari file JSON."""
    with FileLock(LOCK_FILE):
        if not os.path.exists(DATABASE_FILE):
            # Jika file belum ada, buat struktur awal
            with open(DATABASE_FILE, 'w') as f:
                json.dump({"users": {}, "group_settings": {}, "transactions": {}}, f, indent=4)
            return {"users": {}, "group_settings": {}, "transactions": {}}
        
        with open(DATABASE_FILE, 'r') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                # Handle corrupted or empty JSON file
                print(f"Warning: {DATABASE_FILE} is corrupted or empty. Recreating structure.")
                with open(DATABASE_FILE, 'w') as f_new:
                    json.dump({"users": {}, "group_settings": {}, "transactions": {}}, f_new, indent=4)
                return {"users": {}, "group_settings": {}, "transactions": {}}

def save_db(data):
    """Menulis seluruh data ke file JSON."""
    with FileLock(LOCK_FILE):
        with open(DATABASE_FILE, 'w') as f:
            json.dump(data, f, indent=4)

def get_user_data(user_id):
    """Mendapatkan data spesifik user."""
    db = load_db()
    user_id_str = str(user_id)
    return db["users"].get(user_id_str, {})

def update_user_data(user_id, new_data):
    """Memperbarui data spesifik user."""
    db = load_db()
    user_id_str = str(user_id)
    if user_id_str not in db["users"]:
        db["users"][user_id_str] = {}
    db["users"][user_id_str].update(new_data)
    save_db(db)

def get_group_settings(chat_id):
    """Mendapatkan pengaturan spesifik grup."""
    db = load_db()
    chat_id_str = str(chat_id)
    return db["group_settings"].get(chat_id_str, {})

def update_group_settings(chat_id, new_settings):
    """Memperbarui pengaturan spesifik grup."""
    db = load_db()
    chat_id_str = str(chat_id)
    if chat_id_str not in db["group_settings"]:
        db["group_settings"][chat_id_str] = {}
    db["group_settings"][chat_id_str].update(new_settings)
    save_db(db)

def add_transaction_record(transaction_id, data):
    """Menambahkan catatan transaksi baru."""
    db = load_db()
    db["transactions"][str(transaction_id)] = data
    save_db(db)

def get_transaction_record(transaction_id):
    """Mendapatkan catatan transaksi."""
    db = load_db()
    return db["transactions"].get(str(transaction_id))

def update_transaction_record(transaction_id, new_data):
    """Memperbarui catatan transaksi."""
    db = load_db()
    if str(transaction_id) in db["transactions"]:
        db["transactions"][str(transaction_id)].update(new_data)
        save_db(db)

