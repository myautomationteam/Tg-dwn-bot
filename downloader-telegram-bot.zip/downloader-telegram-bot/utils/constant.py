# utils/constants.py

PREMIUM_PRICES = {
    "1_minggu": {"price": 5000, "days": 7, "qris_path_key": "QRIS_5K_PATH"},
    "1_bulan": {"price": 25000, "days": 30, "qris_path_key": "QRIS_25K_PATH"},
    "1_tahun": {"price": 150000, "days": 365, "qris_path_key": "QRIS_150K_PATH"},
}

BASIC_DAILY_LIMIT = 10
PREMIUM_DAILY_LIMIT = 100

# Waktu reset harian (contoh: 00:00 WIB)
RESET_HOUR = 0
RESET_MINUTE = 0
